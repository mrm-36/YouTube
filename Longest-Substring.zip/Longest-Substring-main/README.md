# Longest-Substring
Returns the longuest substring in alphabetical order in a given string.

Check out the video on https://www.youtube.com/channel/UCzw1_BkDtDeaaq9f8PJrJmA.
