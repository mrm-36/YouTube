# Draw

Print an arrow, diamond, and triangle using stars ( * ) and slashes (/\).

Print a n by m grid of numbers from 0 till (n * m - 1) working by columns.

Check out the video on https://www.youtube.com/channel/UCzw1_BkDtDeaaq9f8PJrJmA.
