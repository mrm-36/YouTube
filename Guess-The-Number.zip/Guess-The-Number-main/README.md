# Guess-The-Number

Prompts the user for a number, and uses binary search and user feedback to find the number.

Check out the video on https://www.youtube.com/channel/UCzw1_BkDtDeaaq9f8PJrJmA.
