# Count-Substrings

Given two strings, the program returns the number of times the second string appears in the first.

Check out the video on https://www.youtube.com/channel/UCzw1_BkDtDeaaq9f8PJrJmA.
